﻿using PizzaStoreUML2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#region namespace
namespace PizzaStoreUML2
{
    public class CustomerFile
    {
        #endregion
        #region CreateKunde og Liste
        private static List<Kunder> kundeList = new List<Kunder>();

        public static void CreateKunde(Kunder kunde)
        {
            kundeList.Add(kunde);
            Console.WriteLine($"Kunden {kunde.KundeNavn} er blevet added til list");
        }
        #endregion

        #region ReadKunde
        public static Kunder ReadKunderbyId(int id)
        {
            foreach (Kunder Kunder in kundeList)
            {
                if (Kunder.Id == id)
                {
                    Console.WriteLine(Kunder);
                    return Kunder;
                }
            }
            Console.WriteLine("No Customer found");
            return null;
        }
        #endregion
        #region UpdateKunde
        public static void UpdateKunde(int id, Kunder customer)
        {
            foreach (Kunder kunder in kundeList)
            {
                if (kunder.Id == id)
                {
                    kunder.Id = customer.Id;
                    kunder.KundeAdresse = customer.KundeAdresse;
                    kunder.KundeNavn = customer.KundeNavn;
                    kunder.Emailkunde = customer.Emailkunde;
                }
            }
            Console.WriteLine("Updating Customers Informations....");
        }
        #endregion
        #region RemoveKunde
        public static Kunder RemoveKunderById(int id)
        {
            foreach (Kunder kunder in kundeList)
            {
                if (kunder.Id == id)
                {
                    kundeList.Remove(kunder);
                    Console.WriteLine($"Kunde {kunder.KundeNavn} has been deleted");
                    return kunder;
                }

            }

            return null;
        }
        #endregion
        #region PrintMenu

        public static void PrintMenu()
        {
            foreach (Kunder kunder in kundeList)
            {
                Console.WriteLine(kunder);
            }
        }

    }
}
#endregion