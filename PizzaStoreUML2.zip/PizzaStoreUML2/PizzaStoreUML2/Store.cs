﻿namespace PizzaStoreUML2
{
    internal class store
    {
        public void start()
        {

            #region NewPizza & New Kunder
            // ----- Her opretter vi Pizza Og Kunde ----- //
            Console.WriteLine("=================  PizzaStore  =================");
            Pizza pizza1 = new Pizza("Magherita", "Ost, Tomatsovs, Basilikum. ", 90);
            Pizza pizza2 = new Pizza("Kebab Special", "Ost, Tomatsovs, salat, , kebab ", 130);
            Pizza pizza3 = new Pizza("Italiano", "Ost, tomatsovs, sucuk, æg. ", 135);

            Kunder kunde1 = new Kunder("Hans", "Hedehusene", "33337652", "Hans.busniess@live.dk");
            Kunder kunde2 = new Kunder("Erik", "Greve", "81818282", "Eriksson@hotmail.com");
            Kunder kunde3 = new Kunder("Messi", "Aarhus", "10101010", "Messi@hotmail.dk");

            #endregion
            Console.WriteLine("___________________________________________________________________________________________________");
            //---------------------------------------------------------------------------------------------------------------------//
            //---------------------------------------------------------------------------------------------------------------------//

            #region Create Customer/Pizza
            // ----- Her placere vi de oprettede pizzaer og kunder i listen/dictionary ------ //
            CustomerFile.CreateKunde(kunde1);
            CustomerFile.CreateKunde(kunde2);
            CustomerFile.CreateKunde(kunde3);

            PizzaMenu.CreatePizza(pizza1);
            PizzaMenu.CreatePizza(pizza2);
            PizzaMenu.CreatePizza(pizza3);
            CustomerFile.PrintMenu();
            #endregion
            Console.WriteLine("___________________________________________________________________________________________________");
            //---------------------------------------------------------------------------------------------------------------------//
            //---------------------------------------------------------------------------------------------------------------------//

            #region Opdatering af kunde og pizza og printmenu
            kunde1.Id = 1;
            kunde1.KundeNavn = "Ali";
            kunde1.KundeAdresse = "Ishoj";
            kunde1.Emailkunde = "Aliishoj@live.dk";
            CustomerFile.UpdateKunde(1, kunde1);
            PizzaMenu.UpdatePizza(0, " Hawaii Special", " Tomatsovs, Ananas, Fisk, Tun,", 250);
            PizzaMenu.PrintMenuPizza();
            CustomerFile.PrintMenu();
            //Sletter pizzaen fra menuen


            #endregion
            Console.WriteLine("___________________________________________________________________________________________________");
            //---------------------------------------------------------------------------------------------------------------------//
            //---------------------------------------------------------------------------------------------------------------------//

            #region  RemoveByID Pizza & Kunde


            //Sletter en kunde
            CustomerFile.RemoveKunderById(1);
            PizzaMenu.DeletePizza(0);
            //Printer pizzamenuen ud.
            #endregion
            Console.WriteLine("___________________________________________________________________________________________________");
            //---------------------------------------------------------------------------------------------------------------------//
            //---------------------------------------------------------------------------------------------------------------------//

            #region SearchPizza

            PizzaMenu.FindPizza(1);
            Console.WriteLine("___________________________________________________________________________________________________");
            //---------------------------------------------------------------------------------------------------------------------//
            //---------------------------------------------------------------------------------------------------------------------//
        }
    }
}
#endregion