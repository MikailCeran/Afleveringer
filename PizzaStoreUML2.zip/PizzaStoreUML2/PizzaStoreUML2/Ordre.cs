﻿using PizzaStoreUML2;

public class Ordre
{
    private int _ordreNr;
    Pizza _pizzaItem;
    Kunder _newKunder;



    public Ordre(int ordreNr, Pizza pizzaItem, Kunder newKunder)
    {
        _ordreNr = ordreNr;
        _pizzaItem = pizzaItem;
        _newKunder = newKunder;
    }


    public int ordreNr
    {
        get { return _ordreNr; }
    }

    private double CalculateTotalPrice(double pris)
    {
        return (pris) * 1.25 + 30;
    }

    public override string ToString()
    {
        return $"{{{nameof(ordreNr)}={ordreNr.ToString()}}}";
    }
}
