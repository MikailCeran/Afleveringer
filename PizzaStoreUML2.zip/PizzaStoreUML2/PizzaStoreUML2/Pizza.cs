﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStoreUML2
{
    public class Pizza
    {
        public string _namePizza;
        public string _indholdPizza;
        public int _prisPizza;
        private int _Id;
        public static int idCounter = 0;


        public Pizza(string namePizza, string indholdPizza, int prisPizza)
        {
            _namePizza = namePizza;
            _indholdPizza = indholdPizza;
            _prisPizza = prisPizza;
            _Id = idCounter++;
        }

        public string namePizza
        {
            get { return _namePizza; }
            set { _namePizza = value; }
        }

        public string indholdPizza
        {
            get { return _indholdPizza; }
            set { _indholdPizza = value; }
        }

        public int prisPizza
        {
            get { return _prisPizza; }
            set { _prisPizza = value; }
        }
        public int id
        {
            get { return _Id; }
            set { _Id = value; }
        }

        public override string ToString()
        {
            return $"{{{nameof(namePizza)}={namePizza}, {nameof(indholdPizza)}={indholdPizza}, {nameof(prisPizza)}={prisPizza.ToString()}, {nameof(id)}={id.ToString()}}}";
        }
    }
}
