﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#region Namespace
namespace PizzaStoreUML2
{
    public class PizzaMenu
    {
        #endregion
        #region CreatePizza
        private static Dictionary<int, Pizza> pizzaList = new Dictionary<int, Pizza>();

        public int Count
        {
            get { return pizzaList.Count; }
        }

        public static void CreatePizza(Pizza pizza)  // C
        {
            if (pizzaList.ContainsKey(pizza.id))
            {
                Console.WriteLine($"Pizza already an item");
            }
            else
            {
                pizzaList.Add(pizza.id, pizza);
                Console.WriteLine(@"Pizza added");
            }
        }
        #endregion
        #region ReadPizza
        public static void ReadPizza(int id) // CR
        {
            if (pizzaList.ContainsKey(id))
            {
                Console.WriteLine($"Pizza found:{pizzaList[id]}");
            }
            else
            {
                Console.WriteLine("Pizza not found");
            }
        }
        #endregion
        #region UpdatePizza
        public static void UpdatePizza(int id, string NewName, string NewDescription, int NewPrice) //CRU
        {
            pizzaList[id].prisPizza = NewPrice;
            pizzaList[id].namePizza = NewName;
            pizzaList[id].indholdPizza = NewDescription;
            Console.WriteLine("Pizza Updated");
        }
        #endregion
        #region DeletePizza
        public static void DeletePizza(int id) // CRUD
        {
            if (pizzaList.ContainsKey(id))
            {
                Console.WriteLine($"Pizza has been deleted; {pizzaList[id]}");
            }
            else
            {
                Console.WriteLine("No Pizza has been deleted");
            }
        }
        #endregion
        #region PrintMenuPizza
        public static void PrintMenuPizza() // PRINTMENU
        {
            foreach (var pizza in pizzaList)
            {
                Console.WriteLine(pizza);
            }
        }
        #endregion
        #region SearchPizza


        public static void FindPizza(int id)
        {
            if (pizzaList.ContainsKey(id))
            {
                Console.WriteLine(pizzaList[id]);
            }
            else
            {
                Console.WriteLine("There is no such pizza");
            }
        }


    }

}


#endregion
