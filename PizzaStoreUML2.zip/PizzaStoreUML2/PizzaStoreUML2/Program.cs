﻿using PizzaStoreUML2;

class program
{
    static void Main(string[] args)
    {
        store store = new store();
        store.start();
    }

}