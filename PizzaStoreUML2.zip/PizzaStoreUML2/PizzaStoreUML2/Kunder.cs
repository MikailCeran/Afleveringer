﻿public class Kunder
{
    public static int nextId = 1;
    public Kunder()
    {
        Id = nextId++;
    }
    public Kunder(string nameKunde, string addressKunde, string phoneNumberKunde, string emailkunde)
    {
        Id = nextId++;
        KundeNavn = nameKunde;
        KundeAdresse = addressKunde;
        PhoneNumberKunde = phoneNumberKunde;
        Emailkunde = emailkunde;
    }
    public int Id { get; set; }
    public string KundeNavn { get; set; }
    public string KundeAdresse { get; set; }
    public string PhoneNumberKunde { get; set; }
    public string Emailkunde { get; set; }

    public override string ToString()
    {
        return "Kundens Id er: " + Id + " " + "Kundens navn er: " + KundeNavn + " " + "Adresse: " + KundeAdresse + " " + "Email: " + Emailkunde + " " + "TelefonNummer: " + PhoneNumberKunde;
    }
}
