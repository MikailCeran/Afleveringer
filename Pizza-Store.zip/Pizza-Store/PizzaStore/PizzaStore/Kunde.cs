﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore
{
    public class Kunde
    {
        #region instance field
        private string _navn;
        private string _mail;
        private string _adresse;
        #endregion

        #region Constructor
        public Kunde (string navn, string mail, string adresse)
        {
            _navn = navn;
            _mail = mail;
            _adresse = adresse;
        }
        #endregion

        #region properties
        public string navn { get; }
        public string mail { get; }
        public string adresse{ get; }

        #endregion
        #region method
        public override string ToString()
        {
            return "Kunden navn er : " + _navn + "E-mail er : " + _mail + "Adressen er : " + _adresse;
        }
        #endregion
    }

}
