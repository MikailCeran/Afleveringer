﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaStore
{
    internal class Store
    {
        public void Start()
        {
            Kunde kunde1 = new Kunde("Jens Petersen ", "Jens.petersen@live.dk ", "Peter bangs vej 32");
            Kunde kunde2 = new Kunde("Mikail Ceran ", "ceran123@hotmail.dk ", "Højager 20");
            Kunde kunde3 = new Kunde("Oliver Jensen ", "Oliver.jensen@live.dk ", "vandmosen 32");

            Pizza pizza1 = new Pizza("Magharita ", "2", 50, "Kebab", "Champignon ");
            Pizza pizza2 = new Pizza("Salatpizza ", "1", 60, "Kebab", "salat");
            Pizza pizza3 = new Pizza("Indbagt pizza ", "5", 70, "Kylling, kebab", "cremfraicshe");
            Ordre ordre1 = new Ordre(pizza1, kunde1);
            Ordre ordre2 = new Ordre(pizza2, kunde2);
            Ordre ordre3 = new Ordre(pizza3, kunde3);

            Console.WriteLine(kunde1);
            Console.WriteLine(kunde2);
            Console.WriteLine(kunde3);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(pizza1);
            Console.WriteLine(pizza2);
            Console.WriteLine(pizza3);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine(ordre1);
            Console.WriteLine();
            Console.WriteLine(ordre2);
            Console.WriteLine();
            Console.WriteLine(ordre3);
        }
    }

    
}
