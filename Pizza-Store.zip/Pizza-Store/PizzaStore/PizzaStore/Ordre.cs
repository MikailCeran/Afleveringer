﻿using PizzaStore;
using System.Reflection.Emit;
using System.Reflection.Metadata;

namespace PizzaStore
{
    #region Instance Field
    public class Ordre
    {
        private Pizza _pizzaItems;
        private Kunde _nyKunde;
        #endregion

        #region constructor
        public Ordre(Pizza pizzaitems, Kunde nyKunde)
        {
            _pizzaItems = pizzaitems;
            _nyKunde = nyKunde;
        }
        public double pizzaitems { get; set; }
        #endregion

        #region Methods
        public double CalculateTotalPrice(double pris)
        {
            return (pris) * 1.25 + 40;
        }
        public override string ToString()
        {
            return "Tak for bestillingen! " + "\n" + _nyKunde.navn + "Du har bestilt" + "\n" + _pizzaItems + "Din totale pris er : " + "\n" + CalculateTotalPrice(_pizzaItems.pris);
        }

        #endregion




















}   }
    