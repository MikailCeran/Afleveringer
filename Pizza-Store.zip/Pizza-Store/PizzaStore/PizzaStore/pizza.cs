﻿using PizzaStore;
using System.Reflection.Metadata;

namespace PizzaStore
{
    #region Instance Field
    public class Pizza
    {
        private string _pizza;
        private string _pizzanr;
        private int _pris;
        private string _toppings;
        private string _toppings2;

        #endregion
        #region Constructor
        public Pizza(string pizza, string pizzanr, int pris, string toppings, string toppings2)
        {
            _pizza = pizza;
            _pizzanr = pizzanr;
            _pris = pris;
            _toppings = toppings;
            _toppings2 = toppings2;
        }
        #endregion
        public string pizza { get; set; }
        public string pizzanr { get; set; }
        public int pris
        {
            get { return _pris; }
        }
        public string toppings { get; set; }
        public string toppings2 { get; set; }
        public override string ToString()
        {
            return "Pizza Nummer: " +_pizzanr + " Pizza navn : " + _pizza + "Indeholder" + _toppings +" & "+ _toppings2+ 
                " Pizzaen koster: "+ _pris;
        }

        //pizzaitem.price
    }
}
