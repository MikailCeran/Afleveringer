﻿using PizzaStore;

class program
{
    static void Main(string[] args)
    {
        Store store = new Store();
        store.Start();
    }



}